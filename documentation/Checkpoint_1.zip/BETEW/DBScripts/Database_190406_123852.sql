-- Sport [ent5]
alter table `sport`  add column  `name_2`  varchar(255);


