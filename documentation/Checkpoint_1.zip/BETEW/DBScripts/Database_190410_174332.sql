-- AvailableBetTypes [ent2]
alter table `availablebettypes`  add column  `betresult`  bit;


