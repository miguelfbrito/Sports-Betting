-- AvailableBetTypes [ent2]
alter table `availablebettypes`  add column  `odd`  double precision;


-- BetType [ent6]
alter table `bettype`  add column  `name`  varchar(255);


