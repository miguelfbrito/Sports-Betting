-- Sport [ent5]
alter table `sport`  add column  `name`  varchar(255);


